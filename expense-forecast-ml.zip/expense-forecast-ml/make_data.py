# Creates a larger SYNTHETIC expense history (180 days) in the same format as expenses.csv.
# Real data would be better, but the 4-row sample is too small to train a model.
import csv
import random
from datetime import date, timedelta

random.seed(42)
start = date(2026, 4, 1)
rows = []

meals = [("Breakfast", 40, 90), ("Lunch", 100, 200), ("Dinner", 120, 260)]
shopping_items = [("Notebook", 40, 150), ("Stationery", 30, 120), ("Clothes", 300, 900), ("Headphones", 400, 1200)]

for i in range(180):
    d = start + timedelta(days=i)
    weekend = d.weekday() >= 5

    # Food: lunch and dinner every day, breakfast about half the time, more on weekends
    for name, low, high in meals:
        if name == "Breakfast" and random.random() < 0.5:
            continue
        amount = random.randint(low, high)
        if weekend:
            amount = int(amount * 1.3)
        rows.append([d.isoformat(), "Food", name, amount])

    # Transport: bus on weekdays, occasional auto rides
    if not weekend:
        rows.append([d.isoformat(), "Transport", "Bus fare", random.randint(30, 60)])
    if random.random() < 0.08:
        rows.append([d.isoformat(), "Transport", "Auto ride", random.randint(100, 250)])

    # Shopping: small purchases now and then
    if random.random() < 0.15:
        name, low, high = random.choice(shopping_items)
        rows.append([d.isoformat(), "Shopping", name, random.randint(low, high)])

# A few unusually large purchases for the anomaly detector to find
rows.append([(start + timedelta(days=40)).isoformat(), "Shopping", "Phone repair", 3200])
rows.append([(start + timedelta(days=95)).isoformat(), "Shopping", "Shoes", 2800])
rows.append([(start + timedelta(days=140)).isoformat(), "Transport", "Taxi to airport", 1500])

rows.sort(key=lambda r: r[0])

with open("expenses_large.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Date", "Category", "Description", "Amount"])
    writer.writerows(rows)

print("Wrote", len(rows), "rows to expenses_large.csv")
