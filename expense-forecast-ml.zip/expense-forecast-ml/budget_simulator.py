import csv
import random


# ------------------------------------------------------
# Step 1: Read the historical expense data from the CSV
# ------------------------------------------------------
# Columns: Date, Category, Description, Amount

opened_file = open("expenses.csv")
read_file = csv.reader(opened_file)
expenses_data = list(read_file)
opened_file.close()

# Drop the header row
expenses_data = expenses_data[1:]


# ------------------------------------------------------
# Step 2: Build per-category lists of historical values
# ------------------------------------------------------

food = []
transport = []
shopping = []

for row in expenses_data:
    category = row[1]
    amount = int(row[3])

    if category == "Food":
        food.append(amount)
    elif category == "Transport":
        transport.append(amount)
    elif category == "Shopping":
        shopping.append(amount)


# ------------------------------------------------------
# Step 3: Derive the historical range for each category
# ------------------------------------------------------

food_low = min(food)
food_high = max(food)

transport_low = min(transport)
transport_high = max(transport)

shopping_low = min(shopping)
shopping_high = max(shopping)


# ------------------------------------------------------
# Step 4: Set the per-category weekly budget
# ------------------------------------------------------

food_budget = 180
transport_budget = 45
shopping_budget = 105

weekly_budget = food_budget + transport_budget + shopping_budget


# ------------------------------------------------------
# Step 5: Simulate 12 weeks
# ------------------------------------------------------

total_spent = 0

print("--- Simulated 12-Week Run ---")
print("")

for week in range(1, 13):
    # Generate baseline week's expenses within the historical ranges
    food_cost = random.randint(food_low, food_high)
    transport_cost = random.randint(transport_low, transport_high)
    shopping_cost = random.randint(shopping_low, shopping_high)

    # Roughly 1-in-12 chance of an unexpected transport cost (taxi, auto, etc.)
    if random.randint(1, 12) == 1:
        emergency = random.randint(100, 200)
        transport_cost = transport_cost + emergency

    week_total = food_cost + transport_cost + shopping_cost
    total_spent = total_spent + week_total

    # Build the status message
    week_label = "Week " + str(week)
    spent_label = "spent ₹" + str(week_total)

    if week_total > weekly_budget:
        over_amount = week_total - weekly_budget
        status = "OVER budget by ₹" + str(over_amount)
    elif week_total < weekly_budget:
        under_amount = weekly_budget - week_total
        status = "under budget by ₹" + str(under_amount)
    else:
        status = "exactly on budget"

    print(week_label + ": " + spent_label + " - " + status)


# ------------------------------------------------------
# Step 6: Final summary
# ------------------------------------------------------

total_budgeted = weekly_budget * 12
difference = total_budgeted - total_spent

print("")
print("--- Final Summary ---")
print("Total spent: ₹" + str(total_spent))
print("Total budgeted: ₹" + str(total_budgeted))

if difference > 0:
    print("You came out AHEAD by ₹" + str(difference))
elif difference < 0:
    print("You came out BEHIND by ₹" + str(0 - difference))
else:
    print("You came out exactly even")
