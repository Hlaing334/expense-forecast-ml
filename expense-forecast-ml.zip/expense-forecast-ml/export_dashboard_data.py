# Runs the same model as expense_ai.py and saves the numbers the dashboard shows.
import json
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import KFold, cross_val_predict

np.random.seed(42)
data = pd.read_csv("expenses_large.csv", parse_dates=["Date"])
daily = data.groupby("Date")["Amount"].sum().asfreq("D", fill_value=0)


def make_features(dates):
    return pd.DataFrame({"day_of_week": dates.dayofweek,
                         "is_weekend": (dates.dayofweek >= 5).astype(int),
                         "day_of_month": dates.day}, index=dates)


X, y = make_features(daily.index), daily.values
split = int(len(daily) * 0.8)
model = RandomForestRegressor(n_estimators=200, min_samples_leaf=3, random_state=42)
model.fit(X.iloc[:split], y[:split])
model_mae = mean_absolute_error(y[split:], model.predict(X.iloc[split:]))
baseline_mae = mean_absolute_error(y[split:], np.full(len(y) - split, y[:split].mean()))

# Weekly actuals (full 7-day weeks from the first day)
weeks = len(daily) // 7
actual = []
for w in range(weeks):
    chunk = daily.iloc[w * 7:(w + 1) * 7]
    actual.append({"start": chunk.index[0].strftime("%Y-%m-%d"), "total": int(chunk.sum())})

# Forecast with simulated surprises
model.fit(X, y)
cv_pred = cross_val_predict(RandomForestRegressor(n_estimators=100, min_samples_leaf=3, random_state=42),
                            X, y, cv=KFold(5, shuffle=True, random_state=42))
residuals = y - cv_pred
future = pd.date_range(daily.index[-1] + pd.Timedelta(days=1), periods=84, freq="D")
pred = model.predict(make_features(future))
avg_week = daily.sum() / (len(daily) / 7)
budget = int(round(avg_week * 1.05 / 50) * 50)

runs = 1000
sims = np.zeros((runs, 12))
for r in range(runs):
    for w in range(12):
        sims[r, w] = (pred[w * 7:(w + 1) * 7] + np.random.choice(residuals, size=7)).sum()

forecast = []
for w in range(12):
    forecast.append({"start": future[w * 7].strftime("%Y-%m-%d"),
                     "expected": int(round(pred[w * 7:(w + 1) * 7].sum())),
                     "p10": int(round(np.percentile(sims[:, w], 10))),
                     "p90": int(round(np.percentile(sims[:, w], 90))),
                     "pOver": round(float((sims[:, w] > budget).mean()) * 100)})

behind = float((sims.sum(axis=1) > budget * 12).mean()) * 100
weeks_over = float((sims > budget).sum(axis=1).mean())

# Categories
cats = []
for name, g in data.groupby("Category"):
    cats.append({"name": name, "total": int(g["Amount"].sum()), "count": int(len(g)),
                 "median": int(g["Amount"].median())})
cats.sort(key=lambda c: -c["total"])

# Unusual expenses
feat = pd.DataFrame({"amount": data["Amount"], "category": data["Category"].astype("category").cat.codes,
                     "day_of_week": data["Date"].dt.dayofweek})
data["flag"] = IsolationForest(contamination=0.005, random_state=42).fit_predict(feat)
med = {c["name"]: c["median"] for c in cats}
unusual = []
for _, row in data[data["flag"] == -1].sort_values("Amount", ascending=False).iterrows():
    unusual.append({"date": row["Date"].strftime("%Y-%m-%d"), "category": row["Category"],
                    "description": row["Description"], "amount": int(row["Amount"]),
                    "times": round(row["Amount"] / med[row["Category"]], 1)})

out = {"firstDay": daily.index[0].strftime("%Y-%m-%d"), "lastDay": daily.index[-1].strftime("%Y-%m-%d"),
       "days": len(daily), "transactions": int(len(data)), "avgWeek": int(round(avg_week)), "budget": budget,
       "modelMae": round(model_mae), "baselineMae": round(baseline_mae),
       "chanceBehind": round(behind), "weeksOver": round(weeks_over, 1),
       "actual": actual, "forecast": forecast, "categories": cats, "unusual": unusual}
json.dump(out, open("dashboard_data.json", "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k not in ("actual",)}, indent=1)[:2500])
