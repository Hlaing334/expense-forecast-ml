import random

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import KFold, cross_val_predict

random.seed(42)
np.random.seed(42)

DATA_FILE = "expenses_large.csv"   # use "expenses.csv" once you have a few months of real data
WEEKLY_BUDGET = 0                  # 0 = set automatically from your history (see Step 5)


# ------------------------------------------------------
# Step 1: Load the data and build daily totals
# ------------------------------------------------------

data = pd.read_csv(DATA_FILE, parse_dates=["Date"])

daily = data.groupby("Date")["Amount"].sum()
daily = daily.asfreq("D", fill_value=0)     # days with no spending count as 0

print("--- Data ---")
print("Transactions:", len(data), "| Days:", len(daily),
      "| Average per day: ₹" + str(round(daily.mean())))
print("")


# ------------------------------------------------------
# Step 2: Create features from the calendar
# ------------------------------------------------------

def make_features(dates):
    return pd.DataFrame({
        "day_of_week": dates.dayofweek,
        "is_weekend": (dates.dayofweek >= 5).astype(int),
        "day_of_month": dates.day,
    }, index=dates)


X = make_features(daily.index)
y = daily.values


# ------------------------------------------------------
# Step 3: Train a model and test it on unseen days
# ------------------------------------------------------
# Time-based split: train on the first 80% of days, test on the last 20%

split = int(len(daily) * 0.8)
X_train, X_test = X.iloc[:split], X.iloc[split:]
y_train, y_test = y[:split], y[split:]

model = RandomForestRegressor(n_estimators=200, min_samples_leaf=3, random_state=42)
model.fit(X_train, y_train)

model_error = mean_absolute_error(y_test, model.predict(X_test))
baseline_error = mean_absolute_error(y_test, np.full(len(y_test), y_train.mean()))

print("--- Model Check (last", len(y_test), "days, unseen) ---")
print("Baseline (always guess the average) error: ₹" + str(round(baseline_error)) + " per day")
print("Random Forest error:                      ₹" + str(round(model_error)) + " per day")
print("")


# ------------------------------------------------------
# Step 4: Find unusual expenses (anomaly detection)
# ------------------------------------------------------

features = pd.DataFrame({
    "amount": data["Amount"],
    "category": data["Category"].astype("category").cat.codes,
    "day_of_week": data["Date"].dt.dayofweek,
})

detector = IsolationForest(contamination=0.005, random_state=42)
data["flag"] = detector.fit_predict(features)

print("--- Unusual Expenses ---")
unusual = data[data["flag"] == -1].sort_values("Amount", ascending=False)
for index, row in unusual.iterrows():
    print(row["Date"].date(), "-", row["Category"], "-", row["Description"], "- ₹" + str(row["Amount"]))
print("")


# ------------------------------------------------------
# Step 5: Forecast the next 12 weeks and compare to budget
# ------------------------------------------------------
# Re-train on all data. Add random "surprises" by sampling the model's
# real mistakes (cross-validated errors), so costs like auto rides and
# big purchases show up in the forecast the way they do in real life.

model.fit(X, y)
predicted_in_cv = cross_val_predict(
    RandomForestRegressor(n_estimators=100, min_samples_leaf=3, random_state=42),
    X, y, cv=KFold(5, shuffle=True, random_state=42))
residuals = y - predicted_in_cv

future_days = pd.date_range(daily.index[-1] + pd.Timedelta(days=1), periods=84, freq="D")
future_prediction = model.predict(make_features(future_days))

weekly_average = daily.sum() / (len(daily) / 7)
weekly_budget = WEEKLY_BUDGET if WEEKLY_BUDGET > 0 else int(round(weekly_average * 1.05 / 50) * 50)


def simulate_once():
    weeks = []
    for week in range(12):
        days = future_prediction[week * 7:(week + 1) * 7]
        noise = np.random.choice(residuals, size=7)
        weeks.append(float((days + noise).sum()))
    return weeks


print("--- Simulated 12-Week Run (weekly budget ₹" + str(weekly_budget) + ") ---")
print("")

one_run = simulate_once()
total_spent = 0
for number, week_total in enumerate(one_run, start=1):
    week_total = round(week_total)
    total_spent = total_spent + week_total
    if week_total > weekly_budget:
        status = "OVER budget by ₹" + str(week_total - weekly_budget)
    elif week_total < weekly_budget:
        status = "under budget by ₹" + str(weekly_budget - week_total)
    else:
        status = "exactly on budget"
    print("Week " + str(number) + ": spent ₹" + str(week_total) + " - " + status)

total_budgeted = weekly_budget * 12
difference = total_budgeted - total_spent

print("")
print("--- Final Summary ---")
print("Total spent: ₹" + str(total_spent))
print("Total budgeted: ₹" + str(total_budgeted))
if difference > 0:
    print("You came out AHEAD by ₹" + str(difference))
elif difference < 0:
    print("You came out BEHIND by ₹" + str(0 - difference))
else:
    print("You came out exactly even")


# ------------------------------------------------------
# Step 6: Run the simulation 1000 times to estimate risk
# ------------------------------------------------------

runs = 1000
behind = 0
weeks_over = 0

for run in range(runs):
    result = simulate_once()
    if sum(result) > total_budgeted:
        behind = behind + 1
    for week_total in result:
        if week_total > weekly_budget:
            weeks_over = weeks_over + 1

print("")
print("--- Risk Estimate (" + str(runs) + " simulated 12-week runs) ---")
print("Chance of finishing behind budget: " + str(round(100 * behind / runs)) + "%")
print("Average weeks over budget: " + str(round(weeks_over / runs, 1)) + " out of 12")
