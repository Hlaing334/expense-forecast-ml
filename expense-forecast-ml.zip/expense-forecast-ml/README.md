# Expense Forecast (ML)

A small Python project that learns spending patterns from an expense history, flags unusual expenses, and forecasts the next 12 weeks against a weekly budget.

It started as a simple budget simulator that used random numbers. This version replaces the random numbers with a model trained on the data.

## What it does

1. **Learns spending patterns.** A Random Forest predicts daily spending from the day of the week, whether it is a weekend, and the day of the month. It is tested on the last 20% of days, which it has not seen, and compared with a baseline that always guesses the average.
2. **Finds unusual expenses.** An Isolation Forest flags transactions that stand out by amount, category and day.
3. **Forecasts 12 weeks.** It predicts each week's spending and compares it with the weekly budget. Random "surprises" are sampled from the model's own cross-validated errors.
4. **Estimates risk.** It repeats the 12-week simulation 1,000 times and reports the chance of finishing behind budget and the average number of weeks over budget.

## Results on the sample data

| Measure | Result |
|---|---|
| Average spend | ₹3,688 per week |
| Weekly budget | ₹3,850 |
| Model error on unseen days | ₹114 per day |
| Baseline error (always guess the average) | ₹122 per day |
| Chance of finishing behind budget | 38% |
| Average weeks over budget | 4.1 out of 12 |

Unusual expenses found: phone repair (₹3,200), shoes (₹2,800), taxi to airport (₹1,500) and headphones (₹1,152).

## Files

| File | Purpose |
|---|---|
| `make_data.py` | Creates `expenses_large.csv`, 180 days of **synthetic** expenses |
| `expenses_large.csv` | The generated sample data (`Date,Category,Description,Amount`) |
| `expense_ai.py` | Trains the model, finds unusual expenses, forecasts and estimates risk |
| `export_dashboard_data.py` | Saves the results as `dashboard_data.json` for the dashboard |
| `dashboard/index.html` | A single-page dashboard of the results. Open it in a browser, or host it with GitHub Pages |
| `budget_simulator.py` | The original random simulator, kept for comparison |
| `expenses.csv` | Tiny 4-row example in the same format |

## Run it

```bash
pip install -r requirements.txt
python make_data.py
python expense_ai.py
```

## Dashboard

Open `dashboard/index.html` in any browser. It shows weekly spending, the 12-week forecast against budget, spending by category and the unusual expenses. It needs no internet connection. To refresh it after changing the data, run `python export_dashboard_data.py` and paste the new `dashboard_data.json` content into the `data` script tag in the page.

## Use your own data

Put your expenses in a CSV with the columns `Date,Category,Description,Amount`, then change `DATA_FILE` at the top of `expense_ai.py`. A few months of daily data works much better than a few rows.

## Limitations

- The sample data is **synthetic**. It was generated with simple rules (more food spending at weekends, occasional auto rides and large purchases), so the results show that the code works, not how anyone really spends.
- The model beats the baseline by a small margin. The synthetic data has little pattern apart from the weekend effect, and the model only uses calendar features.
- The day of the month is a weak feature and can add noise to the weekly forecast.
- The risk estimate assumes future surprises look like past ones.

## Ideas to extend it

- Add features such as last week's spending and holidays
- Compare other models, for example gradient boosting
- Forecast by category as well as in total
- Train on real personal or public expense data
